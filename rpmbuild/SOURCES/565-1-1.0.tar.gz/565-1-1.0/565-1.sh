#!/bin/bash
date;
