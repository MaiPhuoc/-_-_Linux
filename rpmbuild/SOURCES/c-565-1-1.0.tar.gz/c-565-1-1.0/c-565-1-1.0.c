#include <stdio.h>
void main()
{
    printf("Hello world, from C\n");
}
